"""Fix the vLLM Voxtral realtime endpoint before the engine imports it.

Applied by the catalog spec's pre-start step inside the engine
container. Repairs three upstream defects of the realtime transcription path:

  1. end-of-audio flush: VoxtralRealtimeBuffer.get_input_stream returned as
     soon as the audio queue signaled end-of-stream, discarding every sample
     that did not fill a whole frame. An utterance without trailing silence
     lost its ending words. At EOF the buffer now zero-pads the partial final
     frame and emits it once, so all arrived audio is decoded.
  2. missing completion event: a final-only input_audio_buffer.commit queued
     the end-of-stream sentinel but never started the generation task, so the
     client received neither transcription.delta nor transcription.done. The
     final commit now also starts generation.
  3. connection/task lifecycle: connection cleanup cancelled the generation
     task without awaiting it, and buffer_realtime_audio cancelled its audio
     and token feeder tasks without gathering them, leaving detached tasks
     whose exceptions were never retrieved. Both now await the cancelled
     tasks.

The patch is deliberately bounded: only the exact upstream sources whose
SHA-256 digests are pinned below are modified, the patched output digests are
pinned as well (a re-run after a container restart is a no-op, a hand-edited
patched file is refused), and any other content fails the container start
loudly instead of running a half-patched engine.
"""
import ast
import hashlib
import importlib.util
import os
from pathlib import Path
import stat
import tempfile


SOURCES = {
    "entrypoints/speech_to_text/realtime/connection.py": {
        "71ef1db59991d9a9084010238419a0866df09a5295ab5d9d45fe4273463bc0c7",
        "4af35919ab980a40ed47febc54e8d7feac9cae320a6a339b6f178d5f0bc27f59",
    },
    "model_executor/models/voxtral_realtime.py": {
        "c2281249cac5de4b574e647e4004202b2a26bc742c92372e8b9bf2de901b5df5",
        "29f63881761397790dd5a48b5ca8f279708bb15f9c9f5bcb210cbf2be58cec7b",
    },
}
MARKER = "# GPUWorks Voxtral realtime EOF and task cleanup, version 1\n"
PATCHED = {
    "entrypoints/speech_to_text/realtime/connection.py": {
        "204259091c61f0088eeccc2d4e180f3cdd2f2f2e517aa52062d01f460013b291",
        "57648bee3122969d8f04eb888d3bf1270a41196068fd021729f6e15a7c90e734",
    },
    "model_executor/models/voxtral_realtime.py": {
        "3f8e7aa66da458f04201614342c5ef014ab81bb71a4ebf4f9bf6f105db28b887",
        "f2aa13e8ad6b145f5b8ac9ec6337083cd504430a025fa9bf5b040b92b017ac33",
    },
}


def replace_once(source, old, new):
    if source.count(old) != 1:
        raise ValueError("Voxtral patch context does not match exactly once")
    return source.replace(old, new, 1)


def patched_source(relative, raw):
    digest = hashlib.sha256(raw).hexdigest()
    if digest not in SOURCES[relative]:
        raise ValueError(f"unsupported Voxtral source {relative}: sha256={digest}")
    source = raw.decode()
    if relative.endswith("connection.py"):
        # A finite upload may finalize without an earlier non-final commit;
        # start generation so the queued audio (and its end sentinel) is
        # consumed and the client receives its transcription events.
        source = replace_once(source,
            "            if commit_event.final:\n                self.audio_queue.put_nowait(None)\n",
            "            if commit_event.final:\n"
            "                self.audio_queue.put_nowait(None)\n"
            "                # A finite upload may finalize without an earlier non-final commit.\n"
            "                await self.start_generation()\n")
        # Await the cancelled generation task so teardown does not leave a
        # detached task writing to a closed socket.
        source = replace_once(source,
            "            self.generation_task.cancel()\n",
            "            self.generation_task.cancel()\n"
            "        if self.generation_task is not None:\n"
            "            await asyncio.gather(self.generation_task, return_exceptions=True)\n")
    else:
        source = replace_once(source,
            "        for frame_size, num_tokens in self._generate_frame_size_and_num_tokens():\n",
            "        emitted_frame = False\n"
            "        for frame_size, num_tokens in self._generate_frame_size_and_num_tokens():\n")
        source = replace_once(source,
            "            while sum(len(arr) for arr in audio_arrays) < frame_size:\n",
            "            final_frame = False\n"
            "            while sum(len(arr) for arr in audio_arrays) < frame_size:\n")
        source = replace_once(source,
            "                if arr is None:\n                    return\n",
            "                if arr is None:\n"
            "                    samples = sum(len(part) for part in audio_arrays)\n"
            "                    overlap = self._look_back_in_samples + self._look_ahead_in_samples\n"
            "                    # EOF must not drop new audio in a partial frame. Only\n"
            "                    # overlap from an already-emitted frame needs no decoding.\n"
            "                    # Invariant: this may discard up to one look_ahead of\n"
            "                    # tail audio; safe only because feed_audio appends\n"
            "                    # right_pad (>= look_ahead in the real config) before\n"
            "                    # the EOF sentinel. Revisit if upstream changes right_pad.\n"
            "                    if samples == 0 or emitted_frame and samples <= overlap:\n"
            "                        return\n"
            "                    audio_arrays.append(np.zeros(frame_size - samples, dtype=audio_arrays[0].dtype))\n"
            "                    final_frame = True\n"
            "                    break\n")
        # Insert after this method's final yield without altering model code.
        tree = ast.parse(source)
        cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == "VoxtralRealtimeBuffer")
        method = next(n for n in cls.body if isinstance(n, ast.AsyncFunctionDef) and n.name == "get_input_stream")
        lines = source.splitlines(keepends=True)
        lines.insert(method.end_lineno,
            "            emitted_frame = True\n"
            "            if final_frame:\n"
            "                return\n")
        source = "".join(lines)
        # Gather the cancelled feeder tasks instead of leaving them detached.
        source = replace_once(source,
            "            audio_task.cancel()\n            token_task.cancel()\n",
            "            audio_task.cancel()\n            token_task.cancel()\n"
            "            await asyncio.gather(audio_task, token_task, return_exceptions=True)\n")
    ast.parse(source)
    return (MARKER + source).encode()


def patch_root(root):
    root = Path(root)
    updates = []
    for relative in SOURCES:
        path = root / relative
        raw = path.read_bytes()
        if raw.startswith(MARKER.encode()):
            if hashlib.sha256(raw).hexdigest() not in PATCHED[relative]:
                raise ValueError(f"modified patched Voxtral source {relative}")
            print(f"voxtral realtime patch: {relative} already patched, skipping")
            continue
        updates.append((path, patched_source(relative, raw)))
    # Validate every source before writing any. Replace instead of truncating:
    # udocker may have hard links to the original image layers.
    for path, data in updates:
        mode = stat.S_IMODE(path.stat().st_mode)
        with tempfile.NamedTemporaryFile(dir=path.parent, delete=False) as staged:
            temporary = Path(staged.name)
            try:
                staged.write(data)
                staged.flush()
                os.fsync(staged.fileno())
                os.chmod(temporary, mode)
                os.replace(temporary, path)
            finally:
                temporary.unlink(missing_ok=True)
        print(f"voxtral realtime patch: patched {path.relative_to(root)}")


if __name__ == "__main__":
    spec = importlib.util.find_spec("vllm")
    if spec is None or not spec.submodule_search_locations:
        raise SystemExit("Voxtral realtime patch requires the catalog vLLM image")
    patch_root(next(iter(spec.submodule_search_locations)))
