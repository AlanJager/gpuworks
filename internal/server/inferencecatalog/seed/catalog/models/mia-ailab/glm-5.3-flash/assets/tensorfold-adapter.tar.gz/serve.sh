#!/usr/bin/env bash
set -euo pipefail

# GPUWorks callable adapter for the measured TensorFold GLM recipe. The
# template places the platform's launch facts with template variables
# (docs/reference/inference-catalog-spec.md, "变量展开"); this script only
# reshapes them into TensorFold's CLI:
#   --model PATH      -> positional checkpoint
#   --headless 0|1    -> a headless rank serves no API, so it gets no --host/--port
# Everything after the platform flags is forwarded to `tensorfold serve`.
model= host= port= tp= rank= headless= master= master_port=
forward=()
while (($#)); do
  case "$1" in
    --model) model=$2; shift 2 ;;
    --host) host=$2; shift 2 ;;
    --port) port=$2; shift 2 ;;
    --tp) tp=$2; shift 2 ;;
    --rank) rank=$2; shift 2 ;;
    --headless) headless=$2; shift 2 ;;
    --master) master=$2; shift 2 ;;
    --master-port) master_port=$2; shift 2 ;;
    *) forward+=("$1"); shift ;;
  esac
done
for required in model tp rank headless master master_port; do
  [[ -n "${!required}" ]] || { echo "gpuworks tensorfold adapter: --${required//_/-} is required" >&2; exit 2; }
done

cmd=(tensorfold serve "$model" --tp "$tp" --rank "$rank" --master "$master" --master-port "$master_port")
if [[ "$headless" == 0 ]]; then
  exec "${cmd[@]}" --host "${host:?--host is required}" --port "${port:?--port is required}" "${forward[@]}"
fi

# A follower can start before the leader has opened its rendezvous; TensorFold
# then exits within seconds. Retry only such early exits: a follower that ran
# longer has really failed and must surface to GPUWorks, not be restarted
# here. The child runs in the background so a container stop reaches it.
child=
trap '[[ -n "$child" ]] && kill -TERM "$child" 2>/dev/null; wait "$child" 2>/dev/null; exit 143' TERM INT
for attempt in $(seq 1 60); do
  started=$SECONDS
  "${cmd[@]}" "${forward[@]}" &
  child=$!
  rc=0
  wait "$child" || rc=$?
  child=
  if ((rc == 0 || SECONDS - started > 120)); then
    exit "$rc"
  fi
  echo "gpuworks tensorfold adapter: follower attempt $attempt exited early (rc=$rc); retrying" >&2
  sleep 5
done
exit "$rc"
