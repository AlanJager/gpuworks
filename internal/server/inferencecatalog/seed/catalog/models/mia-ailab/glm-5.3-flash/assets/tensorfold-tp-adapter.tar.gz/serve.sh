#!/usr/bin/env bash
set -euo pipefail

# GPUWorks callable adapter for TensorFold GLM-5.3-Flash on one host with
# several PCIe Blackwell cards (RTX PRO 6000 / 6000D). The template places the
# platform's launch facts with template variables
# (docs/reference/inference-catalog-spec.md, "变量展开"); this script reshapes
# them into TensorFold's process layout, which is one `tensorfold serve`
# process per GPU on this host:
#   --model PATH      -> positional checkpoint, the same for every rank
#   --tp N            -> N ranks, rank r on the r-th GPU GPUWorks assigned
#   --host/--port     -> rank 0 only; ranks 1..N-1 serve no API
# Everything else is forwarded to every rank's `tensorfold serve`. Engine
# switches (TF_GLM_*, memory reserve, KV pool) arrive as container env.
model= host= port= tp=
forward=()
while (($#)); do
  case "$1" in
    --model) model=$2; shift 2 ;;
    --host) host=$2; shift 2 ;;
    --port) port=$2; shift 2 ;;
    --tp) tp=$2; shift 2 ;;
    *) forward+=("$1"); shift ;;
  esac
done
for required in model host port tp; do
  [[ -n "${!required}" ]] || { echo "gpuworks tensorfold adapter: --${required} is required" >&2; exit 2; }
done
[[ "$tp" =~ ^[1-9][0-9]*$ ]] || { echo "gpuworks tensorfold adapter: --tp must be a positive integer, got '$tp'" >&2; exit 2; }

# The GPUs GPUWorks assigned, in order. Each rank sees its own card first and
# its peers after it (NCCL and CUDA IPC need the peers visible), the same
# rotation the Aevonix launcher uses.
if [[ -n "${CUDA_VISIBLE_DEVICES:-}" ]]; then
  IFS=, read -r -a gpus <<<"$CUDA_VISIBLE_DEVICES"
else
  gpus=(); for ((i = 0; i < tp; i++)); do gpus+=("$i"); done
fi
((${#gpus[@]} == tp)) || {
  echo "gpuworks tensorfold adapter: --tp $tp but ${#gpus[@]} visible GPUs (${CUDA_VISIBLE_DEVICES:-unset})" >&2
  exit 2
}
visible_for() {
  local r=$1 i out=${gpus[$1]}
  for ((i = 0; i < tp; i++)); do ((i == r)) || out+=",${gpus[$i]}"; done
  printf '%s' "$out"
}

# The rendezvous stays on loopback. Pick a free port so two deployments on
# one host never collide on a fixed default.
master_port=$(python3 -c 'import socket; s = socket.socket(); s.bind(("127.0.0.1", 0)); print(s.getsockname()[1])')

pids=()
stop_ranks() {
  ((${#pids[@]})) && kill -TERM "${pids[@]}" 2>/dev/null
  wait 2>/dev/null || true
}
trap 'stop_ranks; exit 143' TERM INT

for ((rank = tp - 1; rank >= 1; rank--)); do
  CUDA_VISIBLE_DEVICES=$(visible_for "$rank") \
    tensorfold serve "$model" --tp "$tp" --rank "$rank" --master 127.0.0.1 --master-port "$master_port" \
    "${forward[@]}" > >(sed -u "s/^/[rank $rank] /") 2>&1 &
  pids+=("$!")
done
CUDA_VISIBLE_DEVICES=$(visible_for 0) \
  tensorfold serve "$model" --tp "$tp" --rank 0 --master 127.0.0.1 --master-port "$master_port" \
  --host "$host" --port "$port" "${forward[@]}" &
pids+=("$!")

# One rank exiting leaves the others blocked in a collective: stop them all
# and surface the first exit code to GPUWorks.
rc=0
wait -n "${pids[@]}" || rc=$?
echo "gpuworks tensorfold adapter: a rank exited with code $rc; stopping the others" >&2
stop_ranks
exit $((rc == 0 ? 1 : rc))
