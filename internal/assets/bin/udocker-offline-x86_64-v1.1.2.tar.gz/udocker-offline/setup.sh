#!/bin/bash
# =============================================================================
# udocker-offline 安装脚本:把 udocker 代码 + 引擎(proot)预置到当前用户目录,
# 全程零网络。原理:udocker 每个命令执行前会跑 do_install() → install()
# (tools.py),install() 先查 is_available():只要 $UDOCKER_DIR/lib/VERSION
# >= 1.2.11 就直接 "installation skipped",不去 incd.pt / GitHub 下载 englib。
#
# 用法(必须以非 root 用户执行,udocker 硬性拒绝 root):
#   bash setup.sh                # 自动启用 patched proot(需要 glibc >= 2.38)
#   bash setup.sh --no-patched   # 只用官方静态 proot
# =============================================================================
set -euo pipefail

PKG_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
UD_DIR="${UDOCKER_DIR:-$HOME/.udocker}"   # udocker 工作目录(顶层,默认 ~/.udocker)
BIN_DIR="$UD_DIR/bin"
LIB_DIR="$UD_DIR/lib"

USE_PATCHED=1
if [ "${1:-}" = "--no-patched" ]; then USE_PATCHED=0; fi

if [ "$(id -u)" = 0 ]; then
    echo "[setup] FATAL: udocker 拒绝以 root 运行,请用普通用户执行本脚本" >&2
    exit 1
fi
command -v python3 >/dev/null || { echo "[setup] FATAL: 需要 python3(如 apt install python3)" >&2; exit 1; }

# 1) 引擎预置:两个静态 proot(不同内核分支各一份)+ VERSION 版本戳
mkdir -p "$BIN_DIR" "$LIB_DIR"
cp -f "$PKG_DIR/englib/bin/proot-x86_64-4_8_0" "$BIN_DIR/"
cp -f "$PKG_DIR/englib/bin/proot-x86_64"       "$BIN_DIR/"
cp -f "$PKG_DIR/englib/lib/VERSION"            "$LIB_DIR/VERSION"
chmod +x "$BIN_DIR"/proot-*
echo "[setup] 引擎预置完成: $BIN_DIR (proot 为静态链接,官方 englib 1.2.11)"

# 2) patched proot(可选):nosocket 补丁版(v1.1.0 起为静态链接,任意 glibc)。
#    先试跑,能跑就覆盖两个 proot 文件名(与 setup_from_cold.sh 同款做法);
#    跑不了(极端环境)自动回退官方静态 proot,不中断安装。
if [ "$USE_PATCHED" = 1 ] && [ -x "$PKG_DIR/patched/proot-nosocket" ]; then
    if "$PKG_DIR/patched/proot-nosocket" --version >/dev/null 2>&1; then
        cp -f "$PKG_DIR/patched/proot-nosocket" "$BIN_DIR/proot-x86_64-4_8_0"
        cp -f "$PKG_DIR/patched/proot-nosocket" "$BIN_DIR/proot-x86_64"
        echo "[setup] patched proot (nosocket) 已启用"
    else
        echo "[setup] WARN: patched proot 需要 glibc >= 2.38,当前主机不满足,"
        echo "[setup]       回退官方静态 proot(无 nosocket 补丁)"
    fi
fi

# 3) 命令入口:包装器写死包路径(不能软链——udocker 入口脚本用 argv[0]
#    拼 sys.path 定位包目录,软链会算错)。
#    关键:先 cd $HOME。若从 root 会话 su 下来且不带 "-",cwd 会继承
#    不可达的 /root(非 root 用户无法 chdir 进),导致 find 管线报
#    "Failed to change directory"、proot 清理助手报 "can't chdir to
#    '/root'" 两类噪音(详见 udocker_offline_package.md 第 6 节)。
mkdir -p "$HOME/.local/bin"
cat > "$HOME/.local/bin/udocker" <<WRAPPER
#!/bin/bash
cd "\$HOME" 2>/dev/null || cd /tmp
exec python3 "$PKG_DIR/udocker/udocker" "\$@"
WRAPPER
chmod +x "$HOME/.local/bin/udocker"

echo "[setup] 完成。确保 ~/.local/bin 在 PATH,然后:"
echo "        udocker version                 # 本地执行,零网络"
echo "        udocker pull alpine:3.20        # 拉镜像(只走 registry)"
echo "        udocker run alpine:3.20 echo hello"
