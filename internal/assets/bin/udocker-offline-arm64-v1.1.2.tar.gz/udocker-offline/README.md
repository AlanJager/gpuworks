# udocker-offline(自包含离线发行包)

免 pip、免运行时引擎下载的 udocker 发行包:官方 Python 代码 + 预编译静态引擎
(proot)+ 自研 patched proot + 一键安装脚本。Linux arm64 可用。

## 为什么

- udocker 官方走 pip / tarball 安装后,**首次运行会联网下载 englib**(proot
  等,~46MB)到 `~/.udocker`。离线包把这一步变成"解包即用"。
- 官方 englib 里的 proot 本来就是静态二进制,预置 + `VERSION` 版本戳后,
  udocker 的 `install()` 检测到已装即跳过(`tools.py`: `is_available()` →
  `"installation skipped"`),运行时零网络。

## 包结构

```
udocker-offline/
├── udocker/                    # 官方 1.3.17 Python 包(纯 stdlib,入口 udocker/udocker)
├── englib/
│   ├── bin/proot-arm64-4_8_0  # 官方静态 proot(kernel >= 4.8 用这个)
│   ├── bin/proot-arm64        # 官方静态 proot(老内核兜底)
│   └── lib/VERSION             # 内容 "1.2.11",is_available() 的判定依据
├── patched/
│   └── proot-temp-noise.patch  # temp.c 清理助手降噪兜底补丁(文档参考,不参与运行时替换)
└── setup.sh                    # 安装脚本(自研 patched proot 由 gpuworks agent 在运行时
                                 #   从内嵌资产 bin/proot-arm64-static-nofd 注入,不在本包内)
```

## 要求

- Linux arm64,kernel >= 3.2(glibc >= 2.38 才可启用 patched proot)
- python3(任何版本 >= 3.6)
- 非 root 用户执行(udocker 硬性拒绝 root)

## 安装与冒烟

```bash
tar xzf udocker-offline-arm64.tar.gz
bash udocker-offline/setup.sh            # --no-patched 只用官方 proot
export PATH="$HOME/.local/bin:$PATH"

udocker version
udocker pull alpine:3.20
udocker run alpine:3.20 echo hello
```

验证零下载:安装后执行 `UDOCKER_LOGLEVEL=DEBUG udocker pull ...`,日志出现
`already installed, installation skipped` 即证明未触发引擎下载。

## 已知噪音(v1.1.0 已修复)

旧版在特定调用方式下(`su udocker -c` 不带 `-`,从 root 会话继承 cwd=/root)
会有两行非致命报错,根因是 **cwd 继承**(详见 `udocker_offline_package.md` 第 6 节):

- `Error: while modifying attributes of image layer` —— find 管线在不可达 cwd 下退出 1
- `proot error: can't chdir to '/root': Permission denied` —— proot 清理助手恢复 cwd 失败

v1.1.0 双保险修复:wrapper 先 `cd $HOME`(治本,对所有引擎生效);
patched proot 含 `proot-temp-noise.patch`(兜底,恢复失败静默回退 `/`)。

## 维护

- 升级 udocker:替换 `udocker/` 目录(官方 release tarball 里的同名目录)。
- 升级引擎:替换 `englib/bin/proot-*` 与 `englib/lib/VERSION`
  (englib 来自 `udocker-englib-<ver>.tar.gz`,VERSION 写该版本号)。
- 需要 runc(F4 模式):从 englib tarball 补 `runc-arm64` 进 `englib/bin/`。
